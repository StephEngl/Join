export interface ContactInterface {
  id?: string;
  name: string;
  phone: string;
  mail: string;
  color?: string;
}
