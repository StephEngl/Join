export interface UserInterface {
  email: string;
  password: string;
}
